library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity full_adder is
    Port ( a    : in  STD_LOGIC;
           b    : in  STD_LOGIC;
           cin  : in  STD_LOGIC;
           s    : out STD_LOGIC;
           cout : out STD_LOGIC);
end full_adder;

architecture structural of full_adder is
    signal s1, c1, c2 : STD_LOGIC;
begin
    HA1: entity work.half_adder 
        port map (a => a, b => b, s => s1, c => c1);
    
    HA2: entity work.half_adder 
        port map (a => s1, b => cin, s => s, c => c2);
    
    cout <= c1 or c2;

end structural;