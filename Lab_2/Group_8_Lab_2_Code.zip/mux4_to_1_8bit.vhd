library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity mux_4to1_8bit is
    Port (
        in0 : in  STD_LOGIC_VECTOR(7 downto 0);
        in1 : in  STD_LOGIC_VECTOR(7 downto 0);
        in2 : in  STD_LOGIC_VECTOR(7 downto 0);
        in3 : in  STD_LOGIC_VECTOR(7 downto 0);
        sel : in  STD_LOGIC_VECTOR(1 downto 0);
        mux_out : out STD_LOGIC_VECTOR(7 downto 0)
    );
end mux_4to1_8bit;

architecture Structural of mux_4to1_8bit is
begin
    GEN_MUX: for i in 0 to 7 generate
        mux_out(i) <= (in0(i) and not sel(1) and not sel(0)) or
                      (in1(i) and not sel(1) and     sel(0)) or
                      (in2(i) and     sel(1) and not sel(0)) or
                      (in3(i) and     sel(1) and     sel(0));
    end generate GEN_MUX;
end Structural;
