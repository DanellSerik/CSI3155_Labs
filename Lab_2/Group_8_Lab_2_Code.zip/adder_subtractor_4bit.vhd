library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder_subtractor_4bit is
    Port ( x            : in  STD_LOGIC_VECTOR (3 downto 0);
           y            : in  STD_LOGIC_VECTOR (3 downto 0);
           add_sub_ctrl : in  STD_LOGIC; -- 0 = Add, 1 = Subtract
	   cin		: in  STD_LOGIC;
           s            : out STD_LOGIC_VECTOR (3 downto 0);
           cout         : out STD_LOGIC;
           overflow     : out STD_LOGIC);
end adder_subtractor_4bit;

architecture structural of adder_subtractor_4bit is
    signal y_xor : STD_LOGIC_VECTOR(3 downto 0);
    signal c     : STD_LOGIC_VECTOR(4 downto 0);
begin
    c(0) <= cin;

    y_xor(0) <= y(0) xor add_sub_ctrl;
    y_xor(1) <= y(1) xor add_sub_ctrl;
    y_xor(2) <= y(2) xor add_sub_ctrl;
    y_xor(3) <= y(3) xor add_sub_ctrl;

    FA0: entity work.full_adder port map (a => x(0), b => y_xor(0), cin => c(0), s => s(0), cout => c(1));
    FA1: entity work.full_adder port map (a => x(1), b => y_xor(1), cin => c(1), s => s(1), cout => c(2));
    FA2: entity work.full_adder port map (a => x(2), b => y_xor(2), cin => c(2), s => s(2), cout => c(3));
    FA3: entity work.full_adder port map (a => x(3), b => y_xor(3), cin => c(3), s => s(3), cout => c(4));

    cout <= c(4);
    
    overflow <= c(3) xor c(4);

end structural;