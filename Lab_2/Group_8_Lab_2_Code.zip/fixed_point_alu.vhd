library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity fixedPointALU is
    Port (
        GClock           : in  STD_LOGIC;
        GReset           : in  STD_LOGIC;
        CLK100MHZ        : in  STD_LOGIC; 
        OperandA         : in  STD_LOGIC_VECTOR(3 downto 0);
        OperandB         : in  STD_LOGIC_VECTOR(3 downto 0);
        OperationSelect  : in  STD_LOGIC_VECTOR(1 downto 0);
        MuxOut           : out STD_LOGIC_VECTOR(7 downto 0);
        CarryOut         : out STD_LOGIC;
        ZeroOut          : out STD_LOGIC;
        OverflowOut      : out STD_LOGIC;
        seg              : out STD_LOGIC_VECTOR(6 downto 0); 
        an               : out STD_LOGIC_VECTOR(7 downto 0)
    );
end fixedPointALU;

architecture Structural of fixedPointALU is

    signal add_sub_res   : STD_LOGIC_VECTOR(3 downto 0);
    signal mult_res      : STD_LOGIC_VECTOR(7 downto 0);
    signal div_quotient  : STD_LOGIC_VECTOR(3 downto 0);
    signal div_remainder : STD_LOGIC_VECTOR(3 downto 0);
    
    signal padded_add_sub_res : STD_LOGIC_VECTOR(7 downto 0);
    signal combined_div_res   : STD_LOGIC_VECTOR(7 downto 0);
    
    signal add_carry     : STD_LOGIC;
    signal add_overflow  : STD_LOGIC;
    signal internal_mux    : STD_LOGIC_VECTOR(7 downto 0);
    signal display_reg_out : STD_LOGIC_VECTOR(7 downto 0);

    signal is_mult_op         : STD_LOGIC;
    signal is_mult_op_delayed : STD_LOGIC;
    signal mult_start_pulse   : STD_LOGIC;

    signal is_div_op          : STD_LOGIC;
    signal is_div_op_delayed  : STD_LOGIC;
    signal div_start_pulse    : STD_LOGIC;

begin

    is_mult_op <= '1' when OperationSelect = "10" else '0';
    mult_start_pulse <= is_mult_op and not is_mult_op_delayed;

    MULT_PULSE_DELAY_DFF: entity work.d_ff port map (
        D      => is_mult_op,
        GClock => GClock,
        GReset => GReset,
        Q      => is_mult_op_delayed
    );

    is_div_op <= '1' when OperationSelect = "11" else '0';
    div_start_pulse <= is_div_op and not is_div_op_delayed;

    DIV_PULSE_DELAY_DFF: entity work.d_ff port map (
        D      => is_div_op,
        GClock => GClock,
        GReset => GReset,
        Q      => is_div_op_delayed
    );

    ADD_SUB_UNIT: entity work.adder_subtractor_4bit port map (
        x            => OperandA,
        y            => OperandB,
        add_sub_ctrl => OperationSelect(0),
        cin          => OperationSelect(0), 
        s            => add_sub_res,
        cout         => add_carry,
        overflow     => add_overflow
    );

    MULT_UNIT: entity work.Signed_Multiplier port map (
        GClock       => GClock,
        GReset       => GReset,
        Start        => mult_start_pulse, 
        OperandA     => OperandA,
        OperandB     => OperandB,
        Product      => mult_res
    );

    DIV_UNIT: entity work.Signed_Divider port map (
        GClock       => GClock,
        GReset       => GReset,
        Start        => div_start_pulse,
        OperandA     => OperandA,
        OperandB     => OperandB,
        Quotient     => div_quotient,
        Remainder    => div_remainder
    );

    padded_add_sub_res <= "0000" & add_sub_res;
    
    combined_div_res   <= div_remainder & div_quotient;

    OUTPUT_MUX: entity work.mux_4to1_8bit port map (
        in0     => padded_add_sub_res,
        in1     => padded_add_sub_res,
        in2     => mult_res,
        in3     => combined_div_res, 
        sel     => OperationSelect,
        mux_out => internal_mux
    );
                    
    MuxOut <= internal_mux;

    DISPLAY_REGISTER: entity work.Reg8 port map (
        D_in   => internal_mux,
        Load   => '1',
        GClock => GClock,
        GReset => GReset,
        Q_out  => display_reg_out 
    );

    CarryOut    <= add_carry when (OperationSelect = "00" or OperationSelect = "01") else '0';
    OverflowOut <= add_overflow when (OperationSelect = "00" or OperationSelect = "01") else '0';
    ZeroOut     <= '1' when internal_mux = "00000000" else '0';

    DISPLAY_UNIT: entity work.display_controller port map (
        clk     => CLK100MHZ,
        data_in => display_reg_out,
        seg     => seg,
        an      => an
    );

end Structural;
