library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Reg4 is
    Port ( D_in   : in  STD_LOGIC_VECTOR (3 downto 0);
           Load   : in  STD_LOGIC;
           GClock : in  STD_LOGIC;
           GReset : in  STD_LOGIC;
           Q_out  : out STD_LOGIC_VECTOR (3 downto 0));
end Reg4;

architecture RTL of Reg4 is
    signal Q_int : STD_LOGIC_VECTOR(3 downto 0);
begin
    process(GClock, GReset)
    begin
        if GReset = '1' then
            Q_int <= (others => '0');
        elsif rising_edge(GClock) then
            if Load = '1' then
                Q_int <= D_in;
            end if;
        end if;
    end process;
    Q_out <= Q_int;
end RTL;