library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Multiplier_Control is
    Port ( GClock       : in  STD_LOGIC;
           GReset       : in  STD_LOGIC;
           INIT         : in  STD_LOGIC;
           Q0           : in  STD_LOGIC;
           is_zero      : in  STD_LOGIC;
           is_done      : in  STD_LOGIC;
           
           loadM        : out STD_LOGIC;
           loadQ        : out STD_LOGIC;
           loadP        : out STD_LOGIC;
           loadC        : out STD_LOGIC;
           selM         : out STD_LOGIC;
           selQ         : out STD_LOGIC;
           selP         : out STD_LOGIC;
           decC         : out STD_LOGIC;
           add_sub_ctrl : out STD_LOGIC
    );
end Multiplier_Control;

architecture Structural of Multiplier_Control is
    signal y_S0, y_S1, y_S2, y_S3 : STD_LOGIC;
    signal D_S0, D_S1, D_S2, D_S3 : STD_LOGIC;
    signal eval : STD_LOGIC;
begin
    eval <= y_S0 or (y_S1 and not is_done);
    
    D_S0 <= INIT; 
    
    D_S1 <= (eval and not Q0) or y_S2 or y_S3;
    D_S2 <= eval and Q0 and not is_zero;
    D_S3 <= eval and Q0 and is_zero;

    FF_S0 : entity work.D_FF port map (D => D_S0, GClock => GClock, GReset => GReset, Q => y_S0);
    FF_S1 : entity work.D_FF port map (D => D_S1, GClock => GClock, GReset => GReset, Q => y_S1);
    FF_S2 : entity work.D_FF port map (D => D_S2, GClock => GClock, GReset => GReset, Q => y_S2);
    FF_S3 : entity work.D_FF port map (D => D_S3, GClock => GClock, GReset => GReset, Q => y_S3);

    loadP <= y_S0 or y_S2 or y_S3;
    loadM <= y_S0 or y_S1;
    loadQ <= y_S0 or y_S1;
    loadC <= y_S0 or y_S1;
    
    selP <= y_S2 or y_S3;
    selM <= y_S1;
    selQ <= y_S1;
    decC <= y_S1;
    add_sub_ctrl <= y_S3;

end Structural;
