library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity Multiplier_Datapath is
    Port ( GClock       : in  STD_LOGIC;
           GReset       : in  STD_LOGIC;
           OperandA     : in  STD_LOGIC_VECTOR (3 downto 0);
           OperandB     : in  STD_LOGIC_VECTOR (3 downto 0);
           
           loadM        : in  STD_LOGIC;
           loadQ        : in  STD_LOGIC;
           loadP        : in  STD_LOGIC;
           loadC        : in  STD_LOGIC;
           selM         : in  STD_LOGIC;
           selQ         : in  STD_LOGIC;
           selP         : in  STD_LOGIC;
           decC         : in  STD_LOGIC;
           add_sub_ctrl : in  STD_LOGIC;
           
           Q0           : out STD_LOGIC;
           is_zero      : out STD_LOGIC;
           is_done      : out STD_LOGIC;
           Product      : out STD_LOGIC_VECTOR (7 downto 0)
    );
end Multiplier_Datapath;

architecture Structural of Multiplier_Datapath is
    -- Internal Signals
    signal M_out, P_out, MUX_M_out, MUX_P_out : STD_LOGIC_VECTOR(7 downto 0);
    signal Q_out, MUX_Q_out                   : STD_LOGIC_VECTOR(3 downto 0);
    signal C_out, MUX_C_out                   : STD_LOGIC_VECTOR(1 downto 0);
    signal ALU_Sum                            : STD_LOGIC_VECTOR(7 downto 0);
    
    signal initM : STD_LOGIC_VECTOR(7 downto 0);
begin
    initM <= OperandA(3) & OperandA(3) & OperandA(3) & OperandA(3) & OperandA;

    MUX_M_out <= initM when selM = '0' else (M_out(6 downto 0) & '0'); -- Left Shift
    MUX_Q_out <= OperandB when selQ = '0' else ('0' & Q_out(3 downto 1)); -- Right Shift
    MUX_P_out <= "00000000" when selP = '0' else ALU_Sum;
    MUX_C_out <= "11" when decC = '0' else (C_out - 1);

    Reg_M: entity work.Reg8 port map (D_in => MUX_M_out, Load => loadM, GClock => GClock, GReset => GReset, Q_out => M_out);
    Reg_P: entity work.Reg8 port map (D_in => MUX_P_out, Load => loadP, GClock => GClock, GReset => GReset, Q_out => P_out);
    
    Reg_Q: entity work.Reg4 port map (D_in => MUX_Q_out, Load => loadQ, GClock => GClock, GReset => GReset, Q_out => Q_out);
    
    Reg_C: entity work.Reg2 port map (D_in => MUX_C_out, Load => loadC, GClock => GClock, GReset => GReset, Q_out => C_out);

    ALU8: entity work.adder_subtractor_8bit port map (
        A        => P_out,
        B        => M_out,
        Add_Sub  => add_sub_ctrl,
        Sum      => ALU_Sum,
        Cout     => open,
        Overflow => open
    );

    Q0      <= MUX_Q_out(0);
    is_zero <= '1' when MUX_C_out = "00" else '0';
    is_done <= '1' when MUX_C_out = "11" else '0';
    Product <= P_out;

end Structural;
