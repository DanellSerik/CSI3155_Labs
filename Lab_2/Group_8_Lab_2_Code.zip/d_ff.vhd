library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity D_FF is
    Port ( D      : in  STD_LOGIC;
           GClock : in  STD_LOGIC;
           GReset : in  STD_LOGIC;
           Q      : out STD_LOGIC);
end D_FF;

architecture behavioural of D_FF is
begin
    process(GClock, GReset)
    begin
        if GReset = '1' then
            Q <= '0';
        elsif rising_edge(GClock) then
            Q <= D;
        end if;
    end process;
end behavioural;
