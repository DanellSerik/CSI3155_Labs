library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_fixedPointALU is
end tb_fixedPointALU;

architecture Behavioral of tb_fixedPointALU is

    signal GClock          : STD_LOGIC := '0';
    signal GReset          : STD_LOGIC := '0';
    signal CLK100MHZ       : STD_LOGIC := '0';
    signal OperandA        : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal OperandB        : STD_LOGIC_VECTOR(3 downto 0) := (others => '0');
    signal OperationSelect : STD_LOGIC_VECTOR(1 downto 0) := "00";
    
    signal MuxOut          : STD_LOGIC_VECTOR(7 downto 0);
    signal CarryOut        : STD_LOGIC;
    signal ZeroOut         : STD_LOGIC;
    signal OverflowOut     : STD_LOGIC;
    signal seg             : STD_LOGIC_VECTOR(6 downto 0);
    signal an              : STD_LOGIC_VECTOR(7 downto 0);

    constant CLK100MHZ_period : time := 10 ns;  -- 100 MHz
    constant GClock_period    : time := 100 ns; 

begin

    uut: entity work.fixedPointALU port map (
        GClock          => GClock,
        GReset          => GReset,
        CLK100MHZ       => CLK100MHZ,
        OperandA        => OperandA,
        OperandB        => OperandB,
        OperationSelect => OperationSelect,
        MuxOut          => MuxOut,
        CarryOut        => CarryOut,
        ZeroOut         => ZeroOut,
        OverflowOut     => OverflowOut,
        seg             => seg,
        an              => an
    );

    clk100_process :process
    begin
        CLK100MHZ <= '0';
        wait for CLK100MHZ_period/2;
        CLK100MHZ <= '1';
        wait for CLK100MHZ_period/2;
    end process;

    gclock_process :process
    begin
        GClock <= '0';
        wait for GClock_period/2;
        GClock <= '1';
        wait for GClock_period/2;
    end process;

    stim_proc: process
    begin       
        GReset <= '1';
        wait for GClock_period * 2;
        GReset <= '0';
        wait for GClock_period;

        -- 3 + 2 = 5
        OperationSelect <= "00";
        OperandA <= "0011"; 
        OperandB <= "0010";
        wait for GClock_period * 2; 

        -- 5 - 2 = 3
        OperationSelect <= "01";
        OperandA <= "0101"; 
        OperandB <= "0010";
        wait for GClock_period * 2;

        -- -8 (1000) - 1 (0001) = Overflow
        OperandA <= "1000"; 
        OperandB <= "0001";
        wait for GClock_period * 2;

        -- 3 * 2 = 6
        OperationSelect <= "10";
        OperandA <= "0011"; 
        OperandB <= "0010";
        
        GReset <= '1';
        wait for GClock_period;
        GReset <= '0';
        wait for GClock_period * 10; 

        -- -2 (1110) * 3 (0011) = -6 (11111010)
        OperandA <= "1110"; 
        OperandB <= "0011";
        
        GReset <= '1';
        wait for GClock_period;
        GReset <= '0';
        
        wait for GClock_period * 10;
        
        -- 7 / 2 
        -- MuxOut = 0001_0011 (Remainder 1, Quotient 3)
        OperationSelect <= "11";
        OperandA <= "0111"; 
        OperandB <= "0010";
        
        GReset <= '1';
        wait for GClock_period;
        GReset <= '0';
        wait for GClock_period * 20;

        -- -6 / 2 
        -- MuxOut = 0000_1101 (Remainder 0, Quotient -3)
        OperandA <= "1010"; 
        OperandB <= "0010";
        
        GReset <= '1';
        wait for GClock_period;
        GReset <= '0';
        
        wait for GClock_period * 20;

        -- -7 / -3 
        -- MuxOut = 1111_0010 (Remainder -1, Quotient 2)
        OperandA <= "1001"; 
        OperandB <= "1101";
        
        GReset <= '1';
        wait for GClock_period;
        GReset <= '0';
        
        wait for GClock_period * 20;

        wait;
    end process;

end Behavioral;
