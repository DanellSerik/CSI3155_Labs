library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity adder_subtractor_8bit is
    Port ( A        : in  STD_LOGIC_VECTOR (7 downto 0);
           B        : in  STD_LOGIC_VECTOR (7 downto 0);
           Add_Sub  : in  STD_LOGIC;
           Sum      : out STD_LOGIC_VECTOR (7 downto 0);
           Cout     : out STD_LOGIC;
           Overflow : out STD_LOGIC);
end adder_subtractor_8bit;

architecture structural of adder_subtractor_8bit is
    signal carry_mid : STD_LOGIC;
begin

    Lower4: entity work.adder_subtractor_4bit 
        port map (
            x        	  => A(3 downto 0),
            y        	  => B(3 downto 0),
            add_sub_ctrl  => Add_Sub,
            cin      	  => Add_Sub,
            s      	  => Sum(3 downto 0),
            cout          => carry_mid,
            overflow 	  => open 
        );

    Upper4: entity work.adder_subtractor_4bit 
        port map (
            x        	  => A(7 downto 4),
            y        	  => B(7 downto 4),
            add_sub_ctrl  => Add_Sub,
            cin      	  => carry_mid,
            s      	  => Sum(7 downto 4),
            cout     	  => Cout,
            overflow 	  => Overflow 
        );
end structural;
