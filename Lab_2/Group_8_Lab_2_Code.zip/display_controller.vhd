library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity display_controller is
    Port (
        clk     : in  STD_LOGIC;                     
        data_in : in  STD_LOGIC_VECTOR(7 downto 0);  
        seg     : out STD_LOGIC_VECTOR(6 downto 0);  
        an      : out STD_LOGIC_VECTOR(7 downto 0)   
    );
end display_controller;

architecture Mixed of display_controller is
    
    signal refresh_counter : STD_LOGIC_VECTOR(15 downto 0) := (others => '0');
    signal active_nibble   : STD_LOGIC_VECTOR(3 downto 0);
    
begin

    HEX_UNIT: entity work.hex_to_cathode port map (
        hex_in  => active_nibble,
        seg_out => seg
    );

        process(clk)
    begin
        if rising_edge(clk) then
            refresh_counter <= refresh_counter + 1;
        end if;
    end process;

        active_nibble <= data_in(3 downto 0) when refresh_counter(15) = '0' else
                     data_in(7 downto 4);

    an(0) <= '0' when refresh_counter(15) = '0' else '1';
    an(1) <= '0' when refresh_counter(15) = '1' else '1';
    
    an(7 downto 2) <= "111111";

end Mixed;
