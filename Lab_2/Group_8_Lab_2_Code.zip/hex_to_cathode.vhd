library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity hex_to_cathode is
    Port (
        hex_in   : in  STD_LOGIC_VECTOR (3 downto 0);
        seg_out  : out STD_LOGIC_VECTOR (6 downto 0) -- seg_out(6)=a, seg_out(0)=g
    );
end hex_to_cathode;

architecture Structural of hex_to_cathode is
begin
    -- Active low encoding (0 = ON, 1 = OFF)
    seg_out <= "0000001" when hex_in = "0000" else 
               "1001111" when hex_in = "0001" else 
               "0010010" when hex_in = "0010" else 
               "0000110" when hex_in = "0011" else 
               "1001100" when hex_in = "0100" else 
               "0100100" when hex_in = "0101" else 
               "0100000" when hex_in = "0110" else 
               "0001111" when hex_in = "0111" else 
               "0000000" when hex_in = "1000" else 
               "0000100" when hex_in = "1001" else 
               "0001000" when hex_in = "1010" else 
               "1100000" when hex_in = "1011" else 
               "0110001" when hex_in = "1100" else 
               "1000010" when hex_in = "1101" else
               "0110000" when hex_in = "1110" else 
               "0111000" when hex_in = "1111" else
               "1111111";
end Structural;

