library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity Signed_Multiplier is
    Port ( GClock   : in  STD_LOGIC;
           GReset   : in  STD_LOGIC;
           Start    : in  STD_LOGIC; -- Maps to INIT
           OperandA : in  STD_LOGIC_VECTOR (3 downto 0);
           OperandB : in  STD_LOGIC_VECTOR (3 downto 0);
           Product  : out STD_LOGIC_VECTOR (7 downto 0)
    );
end Signed_Multiplier;

architecture Structural of Signed_Multiplier is
    signal Q0, is_zero, is_done : STD_LOGIC;
    signal loadM, loadQ, loadP, loadC : STD_LOGIC;
    signal selM, selQ, selP, decC, add_sub_ctrl : STD_LOGIC;
begin

    ControlUnit: entity work.Multiplier_Control port map (
        GClock       => GClock,
        GReset       => GReset,
        INIT         => Start,
        Q0           => Q0,
        is_zero      => is_zero,
        is_done      => is_done,
        loadM        => loadM,
        loadQ        => loadQ,
        loadP        => loadP,
        loadC        => loadC,
        selM         => selM,
        selQ         => selQ,
        selP         => selP,
        decC         => decC,
        add_sub_ctrl => add_sub_ctrl
    );

    DataUnit: entity work.Multiplier_Datapath port map (
        GClock       => GClock,
        GReset       => GReset,
        OperandA     => OperandA,
        OperandB     => OperandB,
        loadM        => loadM,
        loadQ        => loadQ,
        loadP        => loadP,
        loadC        => loadC,
        selM         => selM,
        selQ         => selQ,
        selP         => selP,
        decC         => decC,
        add_sub_ctrl => add_sub_ctrl,
        Q0           => Q0,
        is_zero      => is_zero,
        is_done      => is_done,
        Product      => Product
    );

end Structural;
